# Saviynt Scripts
![image](https://github.com/user-attachments/assets/8877d42b-c4c0-4532-8157-40b6ede02e97)
